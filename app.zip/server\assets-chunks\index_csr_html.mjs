export default `<!DOCTYPE html>
<html lang="en" data-beasties-container="">
<head>
  <meta charset="utf-8">
  <title>App Insights Demo</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles-5INURTSO.css"></head>
<body ngcm="">
  <app-root></app-root>
<script src="main-SHRWVRCW.js" type="module"></script></body>
</html>
`;